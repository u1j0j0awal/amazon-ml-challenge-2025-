"""
Quick High-Performance Solution for Product Price Prediction
Optimized for speed while maintaining high accuracy
"""

import pandas as pd
import numpy as np
import re
from sklearn.model_selection import KFold
from sklearn.preprocessing import StandardScaler, RobustScaler
from sklearn.feature_extraction.text import TfidfVectorizer
import lightgbm as lgb
import warnings
warnings.filterwarnings('ignore')

def extract_features(df):
    """Fast and effective feature extraction"""
    f = pd.DataFrame(index=df.index)
    text = df['catalog_content'].fillna('')
    
    # Basic text stats
    f['len'] = text.str.len()
    f['words'] = text.str.split().str.len()
    f['avg_word'] = f['len'] / (f['words'] + 1)
    f['capitals'] = text.str.count(r'[A-Z]')
    f['digits'] = text.str.count(r'\d')
    
    # Extract all numbers
    nums = text.apply(lambda x: [float(n) for n in re.findall(r'\d+\.?\d*', x)])
    f['n_nums'] = nums.str.len()
    f['max_num'] = nums.apply(lambda x: max(x) if x else 0)
    f['min_num'] = nums.apply(lambda x: min(x) if len(x) > 1 else 0)
    f['sum_nums'] = nums.apply(lambda x: sum(x) if x else 0)
    f['avg_num'] = nums.apply(lambda x: np.mean(x) if x else 0)
    
    # IPQ - critical feature
    f['ipq'] = text.str.extract(r'IPQ[:\s]*(\d+)')[0].fillna(1).astype(float)
    f['log_ipq'] = np.log1p(f['ipq'])
    
    # Weight/volume extraction
    f['ml'] = text.str.extract(r'(\d+\.?\d*)\s*ml')[0].pipe(pd.to_numeric, errors='coerce').fillna(0)
    f['kg'] = text.str.extract(r'(\d+\.?\d*)\s*kg')[0].pipe(pd.to_numeric, errors='coerce').fillna(0)
    f['g'] = text.str.extract(r'(\d+\.?\d*)\s*g(?!b)')[0].pipe(pd.to_numeric, errors='coerce').fillna(0)
    f['l'] = text.str.extract(r'(\d+\.?\d*)\s*l(?:iter)?')[0].pipe(pd.to_numeric, errors='coerce').fillna(0)
    
    # Total weight (important!)
    f['weight'] = f['kg'] * 1000 + f['g'] + f['ml']
    f['log_weight'] = np.log1p(f['weight'])
    f['weight_per_item'] = f['weight'] / (f['ipq'] + 0.01)
    
    # Pack size
    pack = text.str.extract(r'(?:pack\s+of\s+|(\d+)\s+pack)(\d+)')[1]
    f['pack'] = pd.to_numeric(pack, errors='coerce').fillna(1)
    
    # Categories (binary features)
    categories = {
        'electronics': r'electronic|battery|charger|cable|USB|adapter',
        'food': r'food|snack|chocolate|tea|coffee|masala|spice',
        'beverage': r'drink|juice|water|cola|soda|beverage',
        'care': r'shampoo|soap|cream|lotion|oil|wash|face|skin',
        'home': r'cleaner|detergent|cloth|tissue|napkin',
        'health': r'vitamin|protein|supplement|capsule|tablet'
    }
    
    for name, pattern in categories.items():
        f[f'cat_{name}'] = text.str.contains(pattern, case=False, regex=True).astype(int)
    
    # Quality indicators
    f['premium'] = text.str.contains(r'premium|luxury|professional|quality', case=False).astype(int)
    f['organic'] = text.str.contains(r'organic|natural|herbal', case=False).astype(int)
    f['has_brand'] = text.str.contains(r'brand', case=False).astype(int)
    
    # Interactions
    f['ipq_weight'] = f['ipq'] * f['weight']
    f['nums_per_word'] = f['n_nums'] / (f['words'] + 1)
    
    # Fill any remaining NaN
    f = f.fillna(0)
    
    return f

def create_tfidf(train_text, test_text):
    """Create TF-IDF features"""
    vec = TfidfVectorizer(
        max_features=100,
        ngram_range=(1, 2),
        min_df=5,
        max_df=0.8,
        sublinear_tf=True
    )
    
    train_tfidf = vec.fit_transform(train_text).toarray()
    test_tfidf = vec.transform(test_text).toarray()
    
    return train_tfidf, test_tfidf

def smape(y_true, y_pred):
    """SMAPE metric"""
    return np.mean(2 * np.abs(y_pred - y_true) / (np.abs(y_true) + np.abs(y_pred))) * 100

def main():
    print("="*60)
    print("QUICK HIGH-PERFORMANCE PRICE PREDICTION")
    print("="*60)
    
    # Load data
    print("\n[1/5] Loading data...")
    train = pd.read_csv('/content/train.csv')
    test = pd.read_csv('/content/test.csv')
    print(f"Train: {train.shape}, Test: {test.shape}")
    
    # Extract features
    print("\n[2/5] Extracting features...")
    train_feats = extract_features(train)
    test_feats = extract_features(test)
    print(f"Engineered features: {train_feats.shape[1]}")
    
    # TF-IDF
    print("\n[3/5] Creating TF-IDF...")
    train_tfidf, test_tfidf = create_tfidf(
        train['catalog_content'].fillna(''),
        test['catalog_content'].fillna('')
    )
    print(f"TF-IDF features: {train_tfidf.shape[1]}")
    
    # Combine
    X_train = np.hstack([train_feats.values, train_tfidf])
    X_test = np.hstack([test_feats.values, test_tfidf])
    y_train = train['price'].values
    
    print(f"Total features: {X_train.shape[1]}")
    
    # Scale (RobustScaler handles outliers better)
    scaler = RobustScaler()
    X_train = scaler.fit_transform(X_train)
    X_test = scaler.transform(X_test)
    
    # Log transform target
    y_train_log = np.log1p(y_train)
    
    # Train with CV
    print("\n[4/5] Training LightGBM with 5-Fold CV...")
    print("="*60)
    
    params = {
        'objective': 'mae',
        'metric': 'mae',
        'boosting': 'gbdt',
        'num_leaves': 35,
        'learning_rate': 0.04,
        'feature_fraction': 0.8,
        'bagging_fraction': 0.8,
        'bagging_freq': 5,
        'max_depth': 8,
        'min_child_samples': 20,
        'reg_alpha': 0.1,
        'reg_lambda': 0.1,
        'verbose': -1
    }
    
    kf = KFold(n_splits=5, shuffle=True, random_state=42)
    oof = np.zeros(len(X_train))
    preds = np.zeros(len(X_test))
    
    scores = []
    
    for fold, (tr_idx, val_idx) in enumerate(kf.split(X_train), 1):
        print(f"\nFold {fold}/5...")
        
        X_tr, X_val = X_train[tr_idx], X_train[val_idx]
        y_tr, y_val = y_train_log[tr_idx], y_train_log[val_idx]
        
        # Create datasets
        d_train = lgb.Dataset(X_tr, label=y_tr)
        d_val = lgb.Dataset(X_val, label=y_val)
        
        # Train
        model = lgb.train(
            params,
            d_train,
            num_boost_round=2000,
            valid_sets=[d_train, d_val],
            callbacks=[
                lgb.early_stopping(50),
                lgb.log_evaluation(500)
            ]
        )
        
        # Predict
        oof[val_idx] = model.predict(X_val)
        preds += model.predict(X_test) / 5
        
        # Score
        fold_score = smape(np.expm1(y_val), np.expm1(oof[val_idx]))
        scores.append(fold_score)
        print(f"Fold {fold} SMAPE: {fold_score:.4f}")
    
    # Results
    print("\n" + "="*60)
    print("CROSS-VALIDATION RESULTS")
    print("="*60)
    
    oof_score = smape(y_train, np.expm1(oof))
    print(f"\nFold scores: {[f'{s:.4f}' for s in scores]}")
    print(f"Mean ± Std:  {np.mean(scores):.4f} ± {np.std(scores):.4f}")
    print(f"OOF SMAPE:   {oof_score:.4f}")
    
    # Generate submission
    print("\n[5/5] Creating submission...")
    
    final_preds = np.expm1(preds)
    final_preds = np.maximum(final_preds, 0.1)  # Ensure positive
    
    submission = pd.DataFrame({
        'sample_id': test['sample_id'],
        'price': final_preds
    })
    
    submission.to_csv('test_out.csv', index=False)
    
    print("\n" + "="*60)
    print("SUBMISSION CREATED: test_out.csv")
    print("="*60)
    print(f"\nPredictions:")
    print(f"  Count:  {len(final_preds)}")
    print(f"  Min:    ${final_preds.min():.2f}")
    print(f"  Max:    ${final_preds.max():.2f}")
    print(f"  Mean:   ${final_preds.mean():.2f}")
    print(f"  Median: ${np.median(final_preds):.2f}")
    print(f"\n✓ Expected LB Score: ~{oof_score:.2f}")
    print("="*60)

if __name__ == '__main__':
    main()