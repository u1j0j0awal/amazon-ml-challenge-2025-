# ML Challenge 2025: Smart Product Pricing Solution Template

**Team Name:** [Ml]  
**Team Members:** [Ujjawal Saurav, Sachin Barsaiyan, Subhashis Gorai]  
**Submission Date:** [13/10/2025]

1. Methodology Overview
Our approach to this challenge is a multi-modal machine learning pipeline that holistically analyzes both the textual and visual information provided for each product. The core idea is to create rich feature representations from the catalog_content and the product image_link, combine them, and train a powerful gradient boosting model to predict the product's price.

The pipeline consists of three main stages:

Feature Engineering: Separate processing of text and image data to extract meaningful numerical vectors.

Feature Combination: Merging the engineered features into a single, comprehensive feature set for each product.

Model Training: Training a LightGBM Regressor on the combined features to predict the final price.

2. Project Structure and Reproducibility
To ensure our solution is organized and reproducible, we have structured our project into distinct modules for training and prediction. The trained model artifacts are saved to disk, allowing for quick prediction generation without retraining.

/
|-- dataset/
|-- saved_models/
|   |-- lgbm_model.pkl
|   |-- tfidf_vectorizer.pkl
|-- train.py
|-- predict.py
|-- Documentation.md

train.py: This script handles all data preprocessing, feature engineering, and model training. Its final output is the saved model (lgbm_model.pkl) and TF-IDF vectorizer.

predict.py: This script loads the saved artifacts to perform feature engineering on the test set and generate the final test_out.csv submission file.

This modular structure separates concerns, making the workflow clear and easy to reproduce.

3. Feature Engineering Techniques
3.1 Textual Features (catalog_content)
The text data was processed to extract both specific numerical details and broader semantic context.

Item Pack Quantity (IPQ) Extraction: We used regular expressions to find and extract the Item Pack Quantity (e.g., "pack of 6", "count: 2") from the raw catalog_content. This was treated as a crucial numerical feature, with a default value of 1 if no IPQ was found.

TF-IDF Vectorization: The textual content was cleaned (converted to lowercase, punctuation removed) and then vectorized using TfidfVectorizer. To capture more context, we included both unigrams and bigrams (ngram_range=(1, 2)). The vocabulary was limited to the top 20,000 features to maintain computational efficiency.

3.2 Visual Features (Product Images)
To capture features from the product images, we employed a transfer learning approach.

Pre-trained CNN Model: We used a ResNet50 model, pre-trained on the ImageNet dataset, as a feature extractor.

Image Embedding Generation: Each product image was resized to 224×224 pixels and normalized. We then passed it through the pre-trained ResNet50 model (with its final classification layer removed) to generate a 2048-dimensional embedding vector for each image. This vector serves as a rich numerical summary of the visual characteristics of the product. If an image was missing or corrupt, a zero-vector was used as a fallback.

4. Model Architecture and Training
4.1 Feature Combination
The features from the different modalities were combined into a single sparse matrix for the model. The final feature vector for each product had 22,049 dimensions, composed of:

20,000 features from TF-IDF.

2,048 features from the ResNet50 image embeddings.

1 feature for the extracted IPQ.

4.2 Model Selection
We chose the LightGBM (LGBM) Regressor, a highly efficient and powerful gradient boosting framework. It is well-suited for handling the large, sparse feature set we created and is known for its excellent performance on tabular and mixed-data problems.

4.3 Training Details
Target Transformation: The target variable, price, exhibited a skewed distribution. To stabilize the model's training, we applied a logarithmic transformation (log1p) to the price before training.

Training: The LGBM model was trained on the full combined training dataset. We used early stopping to prevent overfitting and find the optimal number of boosting rounds.

5. Final Prediction and Post-processing
For the final submission, the trained model was used to predict on the test dataset.

The model generated predictions in the log-transformed scale.

We applied the inverse transformation (expm1) to convert these predictions back to the original price scale.

As a final sanity check, any predictions that resulted in a negative value were clipped to 0, ensuring all output prices were positive floats.

